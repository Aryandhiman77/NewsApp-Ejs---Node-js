const express = require('express')
const app = express();
const path = require('path')
const Post = require('./models/post.model')
const User = require('./models/user.model')
const mongoose = require('mongoose')
const session = require('express-session');
const checklogin = require('./middleware/login.middleware');
const multer = require('multer');
const fs = require('fs');

let alert ={
    type:false,
    message:""
}
require('./config/db.conn')
let login = false
// static images path
app.use(express.json())
app.use(express.urlencoded({extended:false}))  // -> used to get form data
app.use(express.static(path.join(__dirname, '/images')));

app.use(session({
    secret: 'mY_pRiVate_kEy',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure :false,
        maxAge:10000 *60 *60
     }
  }))

app.set("view engine", "ejs");
app.set("views", 'views')

app.get('/signup',async(req,res)=>{
    if(login){
        res.redirect('/')
    }else{
        let path = '/signup'
        let bool = false
        res.render('signup',{path,login,bool})
    }
    

})

app.post('/saveuser',async(req,res)=>{
try{
    let user = await User.findOne({email:req.body.email})
    if(user){
        let bool = true
        res.render('signup',{bool})
    }
    else{
        let user = await User.create({
            name:req.body.name.toLowerCase(),
            email:req.body.email,
            password:req.body.password,
            useravatar:'../utilities/avatar.jpg'
    })
    login = true
    req.session.user=user
    user && res.redirect('/') 
    }
}
catch(error){
    res.status(500).send('Internal Server Error..')
}
})

app.get('/loginPage',(req,res)=>{
let path = '/loginPage'
if(login){
    res.render('/')
}else{
    bool=false
    res.render('loginPage',{path,login,bool})
}
})


const renderProfile = async(userid)=>{
    let myavatar = await User.findById(userid,{useravatar:1,_id:0})
    myavatar = myavatar.useravatar;
    return myavatar; // this function is async so it will always return a promise
}

app.post('/login',async(req,res)=>{
    try{
        const user = await User.findOne({email:req.body.email})
        if(!user){
            bool =true
            res.render('loginPage',{path,login:false,bool})
        }
        else if (user.password == req.body.password) {
            req.session.user = user
            login = true
            res.redirect('/')
        }else{
            bool = true
            res.render('loginPage',{path,login:false,bool})
        }
         
    }   
    catch(error){
        res.status(500).send('Internal Server Error..')
    }
})





// application level middleware
app.use(checklogin);


app.get('/',async(req,res)=>{
    try {
        let data = await Post.aggregate([{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])
    
    
    
        let path = '/'
        res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
                 
    } catch (error) {
        res.status(500).send('Internal Server Error..')
    }
    
})

app.get('/general', async (req, res) => { 

    try {
        let data =await Post.aggregate([{$match:{category: "General"}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])


        let path = '/general'
        res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
    } catch (error) {
        console.log(error)
        res.status(500).send("Internal Server Error.")
    }

})

app.get('/business',async (req, res) => {
    
        try {
            let data = await Post.aggregate([{$match:{category: "Business"}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])
            
            let path = '/business'
            res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
        } catch (error) {
            console.log(error)
            res.status(500).send("Internal Server Error.")
        }
    
    
    
})
app.get('/entertainment', async (req, res) => {
    
        try {
            let data =await Post.aggregate([{$match:{category: "Entertainment"}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])
            let path = '/entertainment'
            res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
        } catch (error) {
            console.log(error)
            res.status(500).send("Internal Server Error.")
        }
    
    
})
app.get('/sports', async (req, res) => {
    
        try {
            let data =await Post.aggregate([{$match:{category: "Sports"}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])
            let path = '/sports'
            res.render('app', { data,path,login ,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
        } catch (error) {
            console.log(error)
            res.status(500).send("Internal Server Error.")
        }
    
    
    
})
app.get('/politics', async (req, res) => {
    
        try {
            let data =await Post.aggregate([{$match:{category: "Politics"}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])

            let path = '/politics'
            res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
        } catch (error) {
            console.log(error)
            res.status(500).send("Internal Server Error.")
        }
})
app.get('/technology', async (req, res) => {
    
        try {
            let data =await Post.aggregate([{$match:{category: "Technology"}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])

            let path = '/technology'
            res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
        } catch (error) {
            console.log(error)
            res.status(500).send("Internal Server Error.")
        }
})

app.get('/user/:id', async (req, res) => {
    try {
        let userdata = await Post.aggregate([
            {
                $match: { _id: new mongoose.Types.ObjectId(req.params.id) }
            },
            {
                $lookup: {
                    from: "users",
                    localField: "user_name",
                    foreignField: "name",
                    as: "user"
                }
            },
            {
                $unwind: {
                    path: '$user',
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: "categories",
                    localField: "user.cat_id",
                    foreignField: "_id",
                    as: "userCategories"
                }
            },
            {
                $unwind: {
                    path: '$userCategories',
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $group: {
                    _id: "$_id",
                    user_name: { $first: "$user_name" },
                    title: { $first: "$title" },
                    description: { $first: "$description" },
                    image: { $first: "$image" },
                    date: { $first: "$date" },
                    user: { $push: "$user" },
                    mappedCategories: {
                        $addToSet: {
                            cat_id: "$user.cat_id",
                            cat_name: "$userCategories.cat_name"
                        }
                    },
                    ResultCategories: {
                        $first: "$userCategories"
                    }
                }
            },
            {
                $unwind:{
                    path:"$user"
                }
            },
            {
                $project: {
                    user: 1,
                }
            }
        ])

        userdata = userdata[0].user;
        let data = await Post.findById(req.params.id)
        data = await Post.find({user_name:data.user_name})
        res.render('userDetails', {data,userdata,login,user:req.session.user.name})
    } catch (error) {
        res.status(500).send("Internal Server Error.")
    }
       
    
    
})
app.get('/search/:searched',async(req,res)=>{
    // try{
        let searched = (req.params.searched.charAt().toUpperCase()+req.params.searched.substring(1)).toLowerCase()
        if(searched == 'Home' || searched=='home'){
            res.redirect('/')
        }else if(searched =="General" || searched =="general"){
            res.redirect('/general')
        }else if(searched =="Business" || searched =="business"){
            res.redirect('/business')
        }else if(searched =="Entertainment" || searched =="entertainment"){
            res.redirect('/entertainment')
        }else if(searched =="Sports" || searched =="sports"){
            res.redirect('/sports')
        }else if(searched =="Politics" || searched =="politics"){
            res.redirect('/politics')
        }
        else if(searched =="Technology" || searched =="technology"){
            res.redirect('/technology')
        }
        else{
            
                searched = searched.toLowerCase().replaceAll('%20'," "); // replacing all %20 in the url
                const data =await Post.aggregate([{$match:{user_name:searched}},{$lookup:{from:"users",localField:"user_id",foreignField:"_id",as:"Profile_paths"}},{$unwind:{path:'$Profile_paths'}},{$project:{user_name:1,title:1,description:1,category:1,image:1,date:1,Profile_paths:{useravatar:1}}}])

                // res.send(data)  
                data.length>=1?res.render('app', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)}):res.render('404')
           
                // res.status(500).send("Internal Server Error.")
            
        }
    // }catch (error) {
    //     res.status(500).send("Internal Server Error.")
    // }
})
app.get('/news/:id',async(req,res)=>{
    
    try {
            const newsId = req.params.id;
            let data = await Post.findById(newsId)
            // res.send(data)
            let path = '/news/:id'
            res.render('singleNews', { data,path,login,user:req.session.user.name,myavatar:await renderProfile(req.session.user._id)})
        } catch (error) {
            console.log(error)
            res.status(500).send("Internal Server Error.")
        }

})

app.get('/publish',(req,res)=>{
    let bool = true
    let posted=false;
    res.render('publish',{bool,posted,login})
})
const storage = multer.diskStorage({
    destination:(req,file,cb)=>{
        return cb(null,'./images/uploads')
    },
    filename:(req,file,cb)=>{
        return cb(null,`${req.session.user._id}-${Date.now()}${path.extname(file.originalname)}`)
    }
})
const upload = multer({ storage: storage })
app.post('/publish',upload.single('newsImage'),async(req,res)=>{
    try {
        const imgPath = "/"+req.file.path.split('/')[1]+"/"+req.file.path.split('/')[2]
        const myDetails = await User.findById(req.session.user._id)
        const user_name = myDetails.name
    const obj = {
        user_id:req.session.user._id,
        user_name:user_name,
        title:req.body.title,
        description:req.body.description,
        category:req.body.category,
        image:!imgPath?"":imgPath
    }
    // console.log(obj)
    
    const savePost = await Post.create(obj)
    savePost? res.render('publish',{posted:true}):res.render('publish',{posted:false,login})
    } catch (error) {
        console.log(error)
        res.status(500).send("Internal Server Error.")
    }


    
    
})



app.get('/mynews',async(req,res)=>{
    const myUserId = req.session.user._id
    const myEmail = req.session.user.email
    const myPosts = await Post.find({user_id:myUserId})
    const myname = req.session.user.name
    
    let updated = false
    let alert = false
    res.render('myNews',{myPosts,myEmail,myname,updated,alert,myavatar:await renderProfile(req.session.user._id)})
})
app.get('/updateNews/:id',async(req, res) => {
    const post = await Post.findById(req.params.id)
    let updated = false;
    let alert = false
    res.render('updateNews',{post,updated,alert})
});
app.post('/updateNews/:id',upload.single('newsImage'),async(req, res) => {
    try {
        let updateNews = await Post.findById(req.params.id)
        if(req.session.user._id==updateNews.user_id){
        let updateobj={};
        const imgPath =req.file==undefined?"":"/"+req.file.path.split('/')[1]+"/"+req.file.path.split('/')[2]
        if(imgPath==""){
             updateobj={
                title:req.body.title,
                description:req.body.description,
                category:req.body.category
            }
        }
        else{
             updateobj = {
                title:req.body.title,
                description:req.body.description,
                image:!imgPath?"":imgPath,
                category:req.body.category
                
            }
            const imagePath = updateNews.image; // previous image path of news to be updated
            if(imagePath){     
                fs.unlink(`./images${imagePath}`,async function (err) {  // delete the previous image from server
                    if (err){
                        console.log("Some error occured. Please try later.")
                    }  
                });
            }else{
                console.log('No image found. You must delete your post first and re-create it.')
            }
        }
        const post = await Post.findByIdAndUpdate(req.params.id,{$set:updateobj})
        updated = false;
        alert = false;
        post?res.redirect('/mynews'):res.render('updateNews',{alert:true})
    }
    else{
        res.send('Something went wrong.')
    }

    
    } catch (error) {
        res.status(500).send("Internal Server Error.")
    }
});

app.get('/deleteNews/:id', async(req, res) => {
    try{
        let deleteNews = await Post.findById(req.params.id)
        if(req.session.user._id==deleteNews.user_id){
            const imagePath = deleteNews.image;
            if(imagePath){
                fs.unlink(`./images${imagePath}`,async function (err) {
                    if (err){
                        deleteNews = await Post.findByIdAndDelete(req.params.id);
                        deleteNews?res.redirect('/mynews'):res.redirect(`/mynews`)
                    }else{
                        deleteNews = await Post.findByIdAndDelete(req.params.id);
                        deleteNews?res.redirect('/mynews'):res.redirect(`/mynews`)
                    }
                });
            }
            }else{
                res.send('Something went wrong.')
            }
    }catch(err){
        console.log(err)
    }
});

const storage2 = multer.diskStorage({
    destination:(req,file,cb)=>{
        return cb(null,'./images/profiles')
    },
    filename:(req,file,cb)=>{
        return cb(null,`${req.session.user._id}.jpeg`)
    }
})
const upload2 = multer({ storage: storage2 })

app.post('/update/profile',upload2.single('avatarImage'),async (req, res) => {
    const userid = req.session.user._id;
    const imgPath = req.file==undefined?"":"/"+req.file.path.split('/')[1]+"/"+req.file.path.split('/')[2] 
    if(imgPath){
        await User.findByIdAndUpdate(userid,{$set:{
            useravatar : imgPath
        }})
        res.redirect('/mynews')
    }
    else{
        await User.findByIdAndUpdate(userid,{$set:{
            useravatar : "../utilities/avatar.jpg"
        }})
        res.redirect('/mynews')
    }
    
});


app.get('/logout',(req,res)=>{
    login = false;
    req.session.destroy();
    res.redirect('/loginPage')
})
app.get('*', async (req, res) => {
    res.render('404')
    
})



app.listen(8000)

// const insertPostsFromAPI =()=>{
//     let saveGeneral;
//         data.articles.forEach(Element=>{
//              saveGeneral=Post.create({
//                 user_name:!Element.author?"Aryan":Element.author,
//                 title:Element.title,
//                 description:!Element.description?"News is information about current events.News is a report of a current event.":Element.description,
//                 image:!Element.urlToImage?"https://i.pinimg.com/originals/c8/58/90/c85890a5a615f9fc65b2738a13c55460.gif":Element.urlToImage,
//                 date:Element.publishedAt,
//                 category:"Politics"
//             })
//         })
// }

// const insertUsersFromPosts =()=>{
//     let savedata ;
//         let postData =await Post.find({category:"General"},{user_name:1,_id:1})
//         postData.forEach(Element=>{
//              savedata=User.create({
//                 cat_id:Element._id,
//                 name:Element.user_name,
//                 email:"General@gmail.com"
//             })
//         })

//     console.log(postData)
// }


// let data = await Post.aggregate([{$match:{category:"General"}},
//     { $lookup: {from: "categories",
//                 localField: "category",
//                 foreignField: "cat_name",
//                 as: "postcategory" } },
// { $unwind:
//     { path: '$postcategories',
//          preserveNullAndEmptyArrays: true
// } }] )
// app.get('/category/:id', async (req, res) => {
//     
//         const data = await Post.aggregate([
//             {
//                 $match: { _id: new mongoose.Types.ObjectId(req.params.id) }
//             },
//             {
//                 $lookup: {
//                     from: "users",
//                     localField: "user_name",
//                     foreignField: "name",
//                     as: "user"
//                 }
//             },
//             {
//                 $unwind: {
//                     path: '$user',
//                     preserveNullAndEmptyArrays: true
//                 }
//             },
//             {
//                 $lookup: {
//                     from: "categories",
//                     localField: "user.cat_id",
//                     foreignField: "_id",
//                     as: "userCategories"
//                 }
//             },
//             {
//                 $unwind: {
//                     path: '$userCategories',
//                     preserveNullAndEmptyArrays: true
//                 }
//             },
//             {
//                 $group: {
//                     _id: "$_id",
//                     user_name: { $first: "$user_name" },
//                     title: { $first: "$title" },
//                     description: { $first: "$description" },
//                     image: { $first: "$image" },
//                     date: { $first: "$date" },
//                     user: { $push: "$user" },
//                     mappedCategories: {
//                         $addToSet: {
//                             cat_id: "$user.cat_id",
//                             cat_name: "$userCategories.cat_name"
//                         }
//                     },
//                     ResultCategories: {
//                         $first: "$userCategories"
//                     }
//                 }
//             },
//             {
//                 $project: {
//                     _id: 1,
//                     user_name: 1,
//                     title: 1,
//                     description: 1,
//                     image: 1,
//                     date: 1,
//                     user: 1,
//                     mappedCategories: 1
//                 }
//             }
//         ])
//         res.render('userCategories', { data ,login})
//     }
//     else{
//         res.redirect('/signup')
//     }
    
//     //   res.send(data)
    
// })


// db.users.aggregate([{$group:{_id:"$_id"}},{$lookup:{from:"posts",localField:"_id",foreignField:"user_id",as:"Profile_paths"}},{$project:{_id:0}}])