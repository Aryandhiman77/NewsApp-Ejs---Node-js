
const checklogin  = async(req,res,next)=>{
    if(req.session.user){
        next()
    }
    else{
        let login = false
        let bool = false
        res.render('loginPage',{login,bool})
        
    }
}

module.exports = checklogin;