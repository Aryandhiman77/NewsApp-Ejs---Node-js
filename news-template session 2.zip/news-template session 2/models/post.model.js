const mongoose = require('mongoose')
const { Schema }= mongoose;

const postSchema = new Schema({
    user_name:String,
    user_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"user"
    },
    title:String,
    description:String,
    image:String,
    date:{
        type:Date,
        default:Date.now
    },
    category:String,
})

const Post = mongoose.model('posts',postSchema);
module.exports = Post;