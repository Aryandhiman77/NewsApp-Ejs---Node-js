const mongoose = require('mongoose')
const { Schema }= mongoose;

const userSchema = new Schema({
    cat_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"category"
    },
    name:{type:String,unique:true}, 
    password:String,
    email:{type:String,unique:true},
    useravatar:String,
})

const User = mongoose.model('users',userSchema);
module.exports = User;